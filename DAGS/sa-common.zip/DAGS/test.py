from datetime import datetime, timedelta
import pendulum
local_tz = pendulum.timezone("Asia/Seoul")
import sys
sys.path.append('/opt/bitnami/airflow/dags/git_sa-common') #common repo dir in cluster
 
from icis_common import *
COMMON = ICISCmmn(DOMAIN='sa',ENV='dev')
 
custom_env = [
    getICISConfigMap('icis-cmmn-airflow-configmap'),
    getICISSecret('icis-cmmn-airflow-secret'),
    
    getICISConfigMap('icis-samp-batch-file-to-file-configmap'),
    getICISSecret('icis-samp-batch-file-to-file-secret')
]
 
with COMMON.getICISDAG({
    'dag_id':'test_cjs_v1',
    'schedule_interval':'@daily',
    'start_date':datetime(2022, 12, 1 ,00, 00, 0, 0, tzinfo=local_tz),
    #'end_data':datetime(2022, 12, 1 ,00, 00, 0, 0, tzinfo=local_tz), #optional
})as dag:
 
    authCheck=getICISAuthCheckTask('sampJob') #param1 : next_task_id
     
    sampJob = COMMON.getICISKubernetesPodOperator({
        'env_from':custom_env,
        'task_id':'sampJob',
        'image':'nexus.dspace.kt.co.kr/icis/icis-samp-batch-file-to-file:temp07',
        'arguments':["--job.names=sampJob","--yyyyMM=202208"]
    })
     

 
    Complete = getICISCompleteTask()
 
    authCheck >> sampJob  >> Complete
