from datetime import datetime, timedelta
from kubernetes.client import models as k8s
from airflow.providers.http.operators.http import SimpleHttpOperator
from airflow.operators.dummy import DummyOperator
from airflow.operators.python_operator import PythonOperator
from airflow.operators.python import BranchPythonOperator
from airflow.operators.bash import BashOperator
from airflow.operators.empty import EmptyOperator
from airflow.operators.subdag import SubDagOperator
from airflow.utils.trigger_rule import TriggerRule
from airflow.utils.helpers import chain, cross_downstream
from airflow.providers.cncf.kubernetes.operators.kubernetes_pod import (
    KubernetesPodOperator,
)
import pendulum
local_tz = pendulum.timezone("Asia/Seoul")
import sys
sys.path.append('/opt/bitnami/airflow/dags/git_sa-common')

from icis_common_staging import *
COMMON = ICISCmmn(DOMAIN='oder',ENV='sit', NAMESPACE='test-t-order-sit')

with COMMON.getICISDAG({
    'dag_id':'workflow-070501-0.2.sit.0.0',
    'schedule_interval':'0 * * * *',
    'start_date': datetime(2023, 7, 4, 0, 1, 00, tzinfo=local_tz),
    'end_date': datetime(2023, 7, 6, 0, 4, 00, tzinfo=local_tz),
    'paused': False
})as dag:

    authCheck = getICISAuthCheckWflow('69e1d464cd814b88a50f4cb8361223d1')

    test_vol = []
    test_volMnt = []
    test_env = [getICISConfigMap('icis-oder-devbat-configmap'), getICISSecret('icis-oder-devbat-secret')]
    test_env.extend([getICISConfigMap('icis-oder-cmmn-configmap'), getICISSecret('icis-oder-cmmn-secret')])
    test_env.extend([getICISConfigMap('icis-oder-truststore.jks')])

    test = COMMON.getICISKubernetesPodOperator({
        'id' : 'ffe81ae9c27545d7857d910983527d11',
        'volumes': test_vol,
        'volume_mounts': test_volMnt,
        'env_from':test_env,
        'task_id':'test',
        'image':'nexus.dspace.kt.co.kr/icis/icis-oder-devbat:20230622143921',
        'arguments':["--job.names=test"]
    })


    Complete = getICISCompleteWflowTask('69e1d464cd814b88a50f4cb8361223d1')

    authCheck >> test >> Complete
    








